"""Empty wheel."""

__version__ = "0.1.0"
